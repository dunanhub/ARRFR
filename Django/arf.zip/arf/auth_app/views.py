from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import AllowAny
from django.contrib.auth import authenticate
from django.contrib.auth.hashers import check_password
from .models import User  # Убедитесь, что это путь к вашей модели пользователя

class LoginView(APIView):
    # Убираем защиту, чтобы любой мог отправить запрос на логин
    permission_classes = [AllowAny]

    def post(self, request):
        email = request.data.get('email')  # Получаем email из тела запроса
        password = request.data.get('password')  # Получаем пароль из тела запроса

        # Проверка, существует ли пользователь
        try:
            user = User.objects.get(email=email)  # Используем вашу кастомную модель
        except User.DoesNotExist:
            return Response({"error": "User not found"}, status=status.HTTP_404_NOT_FOUND)

        # Проверка пароля
        if not check_password(password, user.password):
            return Response({"error": "Invalid credentials"}, status=status.HTTP_401_UNAUTHORIZED)

        # Логин успешен
        return Response({"message": "Login successful"}, status=status.HTTP_200_OK)
